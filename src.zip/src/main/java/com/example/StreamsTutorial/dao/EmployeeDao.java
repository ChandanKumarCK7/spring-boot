package com.example.StreamsTutorial.dao;

import com.example.StreamsTutorial.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeeDao extends CrudRepository<Employee, Long> {

//    public boolean addData(Employee employee);
//    public Optional<Employee> getDataByID(int id);
//
//    public double getTotalAverageSalary();

    public Employee save(Employee employee);
    public Employee findByid(int id);

    public List<Employee> findAll();

//    public double getTotalAverageSalary();
}
