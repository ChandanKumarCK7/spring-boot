//package com.example.StreamsTutorial.dao;
//
//import com.example.StreamsTutorial.model.Employee;
//import org.springframework.stereotype.Repository;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//@Repository("just")
//public class ImplementsEmployeeDaoInterface implements EmployeeDao{
//
//
////    private List<Employee> db = new ArrayList<>();
////
////    @Override
////    public boolean addData(Employee employee) {
////        long count = db.stream().filter(employee1 -> employee1.getId()==employee.getId()).count();
////        if(count>0){
////            System.out.println("false");
////            return false;
////        }
////        System.out.println("true");
////        db.add(new Employee(employee.getName(),employee.getId(),employee.getSalary(),employee.getGender()));
////        return true;
////    }
////
////    @Override
////    public Optional<Employee> getDataByID(int id) {
////        return db.stream()
////                .filter(employee -> employee.getId()==id).findAny();
////    }
////
////    @Override
////    public double getTotalAverageSalary() {
////        return db.stream().mapToDouble(employee -> employee.getSalary()).average().getAsDouble();
////    }
//
//    private List<Employee> db = new ArrayList<>();
//
//    @Override
//    public boolean addData(Employee employee) {
//        long count = db.stream().filter(employee1 -> employee1.getId()==employee.getId()).count();
//        if(count>0){
//            System.out.println("false");
//            return false;
//        }
//        System.out.println("true");
//        db.add(new Employee(employee.getName(),employee.getId(),employee.getSalary(),employee.getGender()));
//        return true;
//    }
//
//    @Override
//    public Optional<Employee> getDataByID(int id) {
//        return db.stream()
//                .filter(employee -> employee.getId()==id).findAny();
//    }
//
//    @Override
//    public double getTotalAverageSalary() {
//        return db.stream().mapToDouble(employee -> employee.getSalary()).average().getAsDouble();
//    }
//
//
//}
