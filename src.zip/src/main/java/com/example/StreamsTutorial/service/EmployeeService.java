package com.example.StreamsTutorial.service;


import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.example.StreamsTutorial.dao.EmployeeDao;
import com.example.StreamsTutorial.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService implements GraphQLQueryResolver {


    public final EmployeeDao employeeDao;

    @Autowired
    public EmployeeService( EmployeeDao employeeDao){
        this.employeeDao = employeeDao;
    }

    public Employee addData(Employee employee){
        return employeeDao.save(employee);
    }

    public Employee getDatabyID(int id){
        return employeeDao.findByid(id);
    }

    public List<Employee> getAllEmployees(){
        return employeeDao.findAll();
    }

//    public double getTotalAverageSalary(){
//        return employeeDao.getTotalAverageSalary();
//    }

}
