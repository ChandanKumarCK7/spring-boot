package com.example.StreamsTutorial.controllers;

import com.example.StreamsTutorial.model.Employee;
import com.example.StreamsTutorial.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RequestMapping("api/v1/Employee")
@RestController
public class EmployeeAPI {


    EmployeeService employeeService;

    @Autowired
    public EmployeeAPI(EmployeeService employeeService){
        this.employeeService=employeeService;
    }


    @PostMapping
    public boolean addData(@RequestBody Employee employee){
        if(employeeService.addData(employee) != null){
            return true;
        }
        return false;
    }

    @GetMapping("{id}")
    public int getDataByID(@PathVariable("id") int id){
        Employee e = employeeService.getDatabyID(id);
        return e.getId();
    }

//    @GetMapping("/salary")
//    public double getTotalAverageSalary(){
//        return employeeService.getTotalAverageSalary();
//    }
}
