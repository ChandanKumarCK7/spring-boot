package com.example.StreamsTutorial.model;


import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "employee_records")
public class Employee {



    @Column(name ="name")
    String name;
    @Id
    @Column(name = "id")
    int id;
    @Column(name ="salary")
    int salary;
    @Column(name ="gender")
    String gender;

    public Employee() {
    }

    public Employee(@JsonProperty("name") String name, @JsonProperty("id") int id, @JsonProperty("salary") int salary, @JsonProperty("gender") String gender) {
        this.name = name;
        this.id = id;
        this.salary = salary;
        this.gender = gender;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
