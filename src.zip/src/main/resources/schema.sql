create table employee_records (
	id INT,
	name VARCHAR(50),
	salary INT,
	gender VARCHAR(50)
);